import sys
with open("dict.txt", "r") as file:    
    a = file.read()
def efgh90123456(ijkl78901234):
    return klmn34567890(ijkl78901234.decode(), a[85]+a[80]+a[69]+\
a[66]+a[90]) # its not today its tomorrow :)
def yzab90123456():
    return input("\n" + a[33]+a[69]+a[70]+a[77]+a[66]+a[74]+a[69]+a[70]+a[96]+\
a[34]+a[51]+a[41]+a[36]+a[37]+a[51]+a[96]+a[13]+a[96]+a[76]+a[70]+\
a[90]+a[96]+a[74]+a[79]+a[96]+a[90]+a[80]+a[86]+a[83]+a[96]+\
a[69]+a[70]+a[68]+a[83]+a[90]+a[81]+a[85]+a[74]+a[80]+\
a[79]+a[96]+a[76]+a[70]+a[90]+a[84]+a[26]+a[96])
def cdef78901234():
    return open('secret.enc', 'rb').read()
def uvwx12345678(qrst34567890):
    if qrst34567890 == a[35]+a[80]+a[78]+a[34]+a[66]+a[85]+\
a[55]+a[80]+a[78]+a[67]+a[66]+a[52]:
        return True
    else:
        print(a[44]+a[47]+a[44]+a[0]+a[96]+a[52]+a[73]+a[66]+a[85]+a[7]+\
a[84]+a[96]+a[79]+a[80]+a[85]+a[96]+a[72]+a[80]+a[79]+a[79]+a[66]+\
a[96]+a[88]+a[80]+a[83]+a[76]+a[14]+a[96]+a[52]+a[83]+a[90]+\
a[96]+a[66]+a[72]+a[66]+a[74]+a[79]+a[14]+a[14]+a[14])
    sys.exit(0)
def mnop56789012():
    print(a[35]+a[80]+a[78]+a[67]+a[66]+a[85]+a[55]+a[80]+a[78]+a[67]+\
a[66]+a[85]+a[96]+a[74]+a[84]+a[96]+a[68]+a[73]+a[70]+a[68]+a[76]+\
a[74]+a[79]+a[72]+a[96]+a[90]+a[80]+a[86]+a[83]+a[96]+a[76]+a[70]+\
a[90]+a[14]+a[14]+a[14]+a[96]+a[40]+a[70]+a[83]+a[70]+\
a[7]+a[84]+a[96]+a[90]+a[80]+a[86]+a[83]+a[96]+a[71]+\
a[77]+a[66]+a[72]+a[0])
    print("")
def klmn34567890(qrst34567890, abcd12345678):
    ghij56789012 = abcd12345678
    i = 0
    while len(ghij56789012) < len(qrst34567890):
        ghij56789012 = ghij56789012 + abcd12345678[i]
        i = (i + 1) % len(abcd12345678)        
    return "".join([chr(ord(wxyz78901234) ^ ord(stuv90123456)) 
                    for (wxyz78901234,stuv90123456) in zip(qrst34567890,ghij56789012)])
if __name__ == "__main__":
    ijkl78901234 = cdef78901234()
    qrst34567890 = yzab90123456()
    uvwx12345678(qrst34567890)
    mnop56789012()
    abcd12345678 = efgh90123456(ijkl78901234)
    print(abcd12345678)

